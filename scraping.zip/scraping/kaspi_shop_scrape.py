from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

# Set Chrome options to emulate a mobile device
mobile_emulation = {
    "deviceMetrics": {"width": 360, "height": 640, "pixelRatio": 3.0},
    "userAgent": "Mozilla/5.0 (Linux; Android 11; SM-G988B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Mobile Safari/537.36",
}

chrome_options = Options()
chrome_options.add_experimental_option("mobileEmulation", mobile_emulation)

# Initialize Chrome driver with mobile options
driver = webdriver.Chrome(options=chrome_options)

# Load the webpage
driver.get("https://kaspi.kz/")


# Find all elements containing image URLs and date of discounts
link_elements = driver.find_elements(By.CSS_SELECTOR, '.startMainBanner__item')
image_elements = driver.find_elements(By.CSS_SELECTOR, '.startMainBanner__item--img')
date_elements = driver.find_elements(By.CSS_SELECTOR, '.startMainBanner__item--title')

# Extract image URLs and date of discounts
image_urls = []
date_discounts = []
for link_element, image_element, date_element in zip(link_elements, image_elements, date_elements):
    image_url = image_element.get_attribute('style').split('("')[1].split('")')[0] if image_element.get_attribute('style') else image_element.get_attribute('data-background')
    image_urls.append(image_url)
    date_discounts.append(link_element.get_attribute('data-name'))
    counter = counter + 1


# Print the extracted information
for date, url in zip(date_discounts, image_urls):
    
    print("Date of Discount:", date)
    if url:
        print("Image URL:", url)
    else:
        print("Image URL not found")
    print()


# Quit the driver
driver.quit()