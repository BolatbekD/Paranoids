from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up WebDriver
driver = webdriver.Chrome()

try:
    # Open the specific webpage
    driver.get("https://halykbank.kz/card/mycard")

    # Wait for the specific tab panel to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, 'div[x-show="tab == \'tab-1\'"][role="tabpanel"]'))
    )

    # Locate the container with cashback offers
    cashback_container = driver.find_element(By.CSS_SELECTOR, 'div[x-show="tab == \'tab-1\'"][role="tabpanel"]')

    # Extract all paragraphs containing cashback information
    cashback_elements = cashback_container.find_elements(By.CSS_SELECTOR, 'p')

    # Initialize a list to store cashback offers
    cashback_offers = []

    # Process each cashback element
    for element in cashback_elements:
        text = element.text.strip()
        if '–' in text:
            percentage, description = text.split('–', 1)
            cashback_offers.append({
                "percentage": percentage.strip(),
                "description": description.strip()
            })

finally:
    # Close the WebDriver
    driver.quit()

# Output the extracted data
for offer in cashback_offers:
    print(f"{offer['percentage']} - {offer['description']}")
    print("=========================================")