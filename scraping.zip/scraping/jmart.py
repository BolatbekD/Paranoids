from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Initialize Chrome driver
driver = webdriver.Chrome()

try:
    # Load the webpage
    driver.get("https://jmart.kz/promotions")

    # Scroll the page gradually to load all images
    last_height = driver.execute_script("return document.body.scrollHeight")
    while True:
        # Scroll down to bottom
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        # Wait to load page
        time.sleep(2)

        # Calculate new scroll height and compare with last scroll height
        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            break
        last_height = new_height

    # After scrolling, find all image elements again
    image_elements = driver.find_elements(By.CSS_SELECTOR, 'div[data-testid="image"]')

    # Extract image URLs using JavaScript
    image_urls = []
    exclude_list = ['qrCode', 'appstore', 'playmarket', 'phoneBonus']  # List of strings to exclude

    for element in image_elements:
        image_url = driver.execute_script(
            "return window.getComputedStyle(arguments[0], null).getPropertyValue('background-image');",
            element
        )
        # Remove the 'url()' part from the style
        image_url = image_url.replace('url("', '').replace('")', '').replace('url(', '').replace(')', '')

        # Check if the URL contains any of the excluded strings
        if image_url and image_url != 'none' and not any(excl in image_url for excl in exclude_list):
            image_urls.append(image_url)

    # Print the extracted image URLs
    for url in image_urls:
        print("Image URL:", url)
    print(f"Total images found: {len(image_urls)}")

except Exception as e:
    print("An error occurred:", e)
finally:
    # Quit the driver
    driver.quit()
