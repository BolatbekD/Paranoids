# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.by import By

# Step 1: Scraping Jusan QR and Jusan Mobile bonuses
driver = webdriver.Chrome()

# Load the webpage
driver.get("https://jusan.kz/bonus")



# Find all elements containing the bonus details
bonus_elements = driver.find_elements(By.CSS_SELECTOR, '.bonus-guarantee_guarantee_name__6cBhd')

# Extract bonus details for Jusan QR and Jusan Mobile
jusan_bonus_details = []
for element in bonus_elements:
    # Extract bonus name
    bonus_name = element.find_element(By.TAG_NAME, 'p').text.strip()
    
    # Extract bonus description
    bonus_description = element.find_elements(By.TAG_NAME, 'p')[1].text.strip()
    
    # Extract bonus percentage
    bonus_percentage = element.find_element(By.CSS_SELECTOR, '.bonus-guarantee_bonus_badge__LE1Ob span').text.strip()
    
    # Check if bonus name is either "Jusan QR" or "Jusan Mobile"
    if bonus_name == "Jusan QR" or bonus_name == "Jusan Mobile":
        # Append bonus details for Jusan QR and Jusan Mobile
        jusan_bonus_details.append({
            "Name": bonus_name,
            "Description": bonus_description,
            "Percentage": bonus_percentage
        })

# Step 2: Scraping categories and their images
# Step 3: Scraping additional categories and their images
# Step 4: Scraping more additional categories and their images
categories = [
    {'id': 'increased-bonus_categories_container_0__szUXq', 'name': 'categories'},
    {'id': 'increased-bonus_categories_container_1__Z7qzD', 'name': 'additional_categories'},
    {'id': 'increased-bonus_categories_container_2__kCoqt', 'name': 'more_additional_categories'}
]

# Initialize category_details list
category_details = []

# Iterate through each category type
for cat_type in categories:
    # Find the container holding all the category blocks
    categories_container = driver.find_element(By.ID, cat_type['id'])

    # Find all elements containing the category blocks
    category_blocks = categories_container.find_elements(By.CLASS_NAME, 'increased-bonus_category_block__Ww7Jt')

    # Extract category details
    for block in category_blocks:
        # Extract category name
        category_name = block.find_element(By.CSS_SELECTOR, 'div.increased-bonus_child_text__U_X2p p:nth-of-type(1)').text.strip()

        # Extract image URL
        image_url = block.find_element(By.TAG_NAME, 'img').get_attribute('src')

        # Append category details to the category_details list
        category_details.append({
            "Category Name": category_name,
            "Image URL": image_url
        })

# Print the extracted information for Jusan QR and Jusan Mobile
for bonus in jusan_bonus_details:
    print("Bonus Name:", bonus["Name"])
    print("Description:", bonus["Description"])
    print("Percentage:", bonus["Percentage"])
    print()


# Print the extracted information for all categories
for category in category_details:
    print("Category Name:", category["Category Name"])
    print("Image URL:", category["Image URL"])
    print()


# Quit the driver
driver.quit()