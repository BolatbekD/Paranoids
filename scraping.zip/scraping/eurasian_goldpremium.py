from selenium import webdriver
from selenium.webdriver.common.by import By

# Set up WebDriver
driver = webdriver.Chrome()

# Open the web page
driver.get("https://eubank.kz/bonus-program/")

try:
    # Click on the "Gold, Premium" tab
    driver.find_element(By.XPATH, "//div[contains(@class, 'tab__control') and contains(text(), 'Gold, Premium')]").click()

    # Check if the "Gold, Premium" tab is active
    is_gold_premium_active = "is-active" in driver.find_element(By.XPATH, "//div[contains(@class, 'tab__control') and contains(text(), 'Gold, Premium')]").get_attribute("class")

    # Common bonuses
    common_bonus_1 = driver.find_element(By.CSS_SELECTOR, "#tab > div.tab__contents > div.tab__section.is-active > div.tab__inner > ul > li:nth-child(2)")
    common_bonus_1_text = common_bonus_1.text
    common_bonus_1_per, common_bonus_1_title = common_bonus_1_text.split(' ', 1)
    common_bonus_2 = driver.find_element(By.CSS_SELECTOR, "#tab > div.tab__contents > div.tab__section.is-active > div.tab__inner > ul > li:nth-child(3)")
    common_bonus_2_text = common_bonus_2.text
    common_bonus_2_per, common_bonus_2_title = common_bonus_2_text.split(' ', 1)

    # Print the bonuses
    print("Percentage:", common_bonus_1_per)
    print("Title:", common_bonus_1_title)

    print("Percentage:", common_bonus_2_per)
    print("Title:", common_bonus_2_title)

finally:
    # Quit the WebDriver
    driver.quit()