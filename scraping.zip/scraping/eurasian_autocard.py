from selenium import webdriver
from selenium.webdriver.common.by import By

# Set up WebDriver
driver = webdriver.Chrome()

# Open the web page
driver.get("https://eubank.kz/bonus-program/")

try:
    # Find the bonuses for the "Авто" category
    auto_bonuses = driver.find_element(By.CSS_SELECTOR, "#tab div.tab__contents div.tab__section.is-active div.tab__inner ul:nth-child(4) li:nth-child(2)").text

    # Find the bonuses for the "Развлечения" category
    entertainment_bonuses = driver.find_element(By.CSS_SELECTOR, "#tab div.tab__contents div.tab__section.is-active div.tab__inner ul:nth-child(4) li:nth-child(3)").text

    # Parse bonuses into percentage and title fields for Авто
    auto_percentage, auto_title = auto_bonuses.split(' ', 1)

    # Parse bonuses into percentage and title fields for Развлечения
    entertainment_percentage, entertainment_title = entertainment_bonuses.split(' ', 1)

    # Common bonuses
    common_bonus_1 = driver.find_element(By.CSS_SELECTOR, "#tab > div.tab__contents > div.tab__section.is-active > div.tab__inner > ul:nth-child(3) > li:nth-child(2)")
    common_bonus_1_text = common_bonus_1.text
    common_bonus_1_per, common_bonus_1_title = common_bonus_1_text.split(' ', 1)
    
    common_bonus_2 = driver.find_element(By.CSS_SELECTOR, "#tab > div.tab__contents > div.tab__section.is-active > div.tab__inner > ul:nth-child(4) > li:nth-child(1)")
    common_bonus_2_text = common_bonus_2.text
    common_bonus_2_per, common_bonus_2_title = common_bonus_2_text.split(' ', 1)

    # Print the bonuses
    print("Percentage:", common_bonus_1_per)
    print("Title:", common_bonus_1_title)
    
    print("Percentage:", common_bonus_2_per)
    print("Title:", common_bonus_2_title)
    
    print("Percentage:", auto_percentage)
    print("Title:", auto_title)
    
    print("Percentage:", entertainment_percentage)
    print("Title:", entertainment_title)

finally:
    # Quit the WebDriver
    driver.quit()
