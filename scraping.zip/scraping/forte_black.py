import re
from selenium import webdriver
from selenium.webdriver.common.by import By

# Set up WebDriver
driver = webdriver.Chrome()

# Open the ForteBank Black card page
driver.get("https://forte.kz/black#!")

try:
    # Find and print the common bonuses for the Black card
    # Common bonuses
    common_bonus_1 = driver.find_element(By.CSS_SELECTOR, "#__next > main > div:nth-child(26) > div > div.sc-bPLjHf.fHJNIN > div.sc-hQYogJ.kFJMbO > p:nth-child(1)")
    common_bonus_1_text = common_bonus_1.text

    # Extract percentage and title
    match = re.search(r'(\d+%)', common_bonus_1_text)  # Find percentage using regex
    common_bonus_1_per = match.group(1) if match else ""  # Extract percentage if found
    common_bonus_1_title = common_bonus_1_text.strip()  # Remove percentage from title

    common_bonus_2 = driver.find_element(By.CSS_SELECTOR, "#__next > main > div:nth-child(26) > div > div.sc-bPLjHf.fHJNIN > div.sc-hQYogJ.kFJMbO > p:nth-child(2)")
    common_bonus_2_text = common_bonus_2.text

    # Extract percentage and title
    match = re.search(r'(\d+%)', common_bonus_2_text)  # Find percentage using regex
    common_bonus_2_per = match.group(1) if match else ""  # Extract percentage if found
    common_bonus_2_title = common_bonus_2_text.strip()  # Remove percentage from title

    # Print the bonuses
    print("Percentage: <", common_bonus_1_per)
    print("Title:", common_bonus_1_title)
    
    print("Percentage: <", common_bonus_2_per)
    print("Title:", common_bonus_2_title)

finally:
    # Close the WebDriver
    driver.quit()
