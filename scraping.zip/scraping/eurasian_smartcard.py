from selenium import webdriver
from selenium.webdriver.common.by import By

# Set up WebDriver
driver = webdriver.Chrome()

# Open the web page
driver.get("https://eubank.kz/bonus-program/")

try:
    smartcard_tab = driver.find_element(By.XPATH, "//div[contains(@class, 'tab__control') and contains(text(), 'SmartCard')]")
    smartcard_tab.click()

    # Wait for the SmartCard bonuses to be visible
    smartcard_bonuses = driver.find_element(By.CSS_SELECTOR, "#tab div.tab__contents div.tab__section.is-active div.tab__inner ul li:nth-child(4)")

    # Parse bonuses into percentage and title fields for SmartCard
    smartcard_text = smartcard_bonuses.text
    smartcard_percentage, smartcard_title = smartcard_text.split(' ', 1)


    common_bonus_1 = driver.find_element(By.CSS_SELECTOR, "#tab > div.tab__contents > div.tab__section.is-active > div.tab__inner > ul > li:nth-child(2)")
    common_bonus_1_text = common_bonus_1.text
    common_bonus_1_per, common_bonus_1_title = common_bonus_1_text.split(' ', 1)
    
    common_bonus_2 = driver.find_element(By.CSS_SELECTOR, "#tab > div.tab__contents > div.tab__section.is-active > div.tab__inner > ul > li:nth-child(3)")
    common_bonus_2_text = common_bonus_2.text
    common_bonus_2_per, common_bonus_2_title = common_bonus_2_text.split(' ', 1)
    
    
    # Print the bonuses
    print("Percentage:", common_bonus_1_per)
    print("Title:", common_bonus_1_title)
    
    print("Percentage:", common_bonus_2_per)
    print("Title:", common_bonus_2_title)
    
    print("Percentage:", smartcard_percentage)
    print("Title:", smartcard_title)

finally:
    # Quit the WebDriver
    driver.quit()
