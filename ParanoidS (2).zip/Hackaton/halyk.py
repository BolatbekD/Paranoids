from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import io
import os
from google.cloud import vision
from google.oauth2 import service_account
import openai
import firebase_admin
from firebase_admin import credentials, firestore
import json
import re
# Set up WebDriver
driver = webdriver.Chrome()

try:
    # Open the specific webpage
    driver.get("https://halykbank.kz/card/mycard")

    # Wait for the specific tab panel to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, 'div[x-show="tab == \'tab-1\'"][role="tabpanel"]'))
    )

    # Locate the container with cashback offers
    cashback_container = driver.find_element(By.CSS_SELECTOR, 'div[x-show="tab == \'tab-1\'"][role="tabpanel"]')

    # Extract all paragraphs containing cashback information
    cashback_elements = cashback_container.find_elements(By.CSS_SELECTOR, 'p')

    # Initialize a list to store cashback offers
    cashback_offers = []

    # Process each cashback element
    for element in cashback_elements:
        text = element.text.strip()
        if '–' in text:
            percentage, description = text.split('–', 1)
            cashback_offers.append({
                "percentage": percentage.strip(),
                "description": description.strip()
            })

finally:
    # Close the WebDriver
    driver.quit()

# Output the extracted data
key_path = r"C:\Users\user\Desktop\Hackaton\neat-bricolage-420211-firebase-adminsdk-tzra2-5d9980111e.json"
cred = credentials.Certificate(key_path)
firebase_admin.initialize_app(cred)
db = firestore.client()



db.collection("QR").document("Halyk").set({"cashback_rate": cashback_offers[0]['percentage'].replace('+', '').replace('%', '')})
db.collection("Card").document("Halyk").set({"cashback_rate": cashback_offers[1]['percentage'].replace('+', '').replace('%', '')})
db.collection("Special").document("Halyk").set({
    "first_rate": cashback_offers[2]['percentage'].replace('+', '').replace('%', ''),
    "first_description": cashback_offers[2]['description'],
    "second_rate": cashback_offers[3]['percentage'].replace('+', '').replace('%', ''),
    "second_description": cashback_offers[3]['description']
})

for offer in cashback_offers:
    print(f"{offer['percentage']} - {offer['description']}")
    print("=========================================")
