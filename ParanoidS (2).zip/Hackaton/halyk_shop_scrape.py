import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Launch the Chrome browser
driver = webdriver.Chrome()

# Open the webpage
driver.get("https://halykbank.kz/promo")

try:
    # Wait for the promo boxes to load
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, '#stock-wrap > div > a')))

    # Find all promo boxes
    promo_boxes = driver.find_elements(By.CSS_SELECTOR, '#stock-wrap > div > a')

    # Create lists to store the extracted data
    promo_data = []

    # Iterate through each promo box
    for box in promo_boxes:
        # Get the text of the promo description
        promo_text = box.find_element(By.CSS_SELECTOR, 'div > div > div').text

        # Check if the promo contains "%"
        if "%" in promo_text:
            # Click on the promo box to navigate to the promo page
            box.click()

            # Define the CSS selector for the promo details container
            promo_details_css = 'div.border-b.border-gray-100.pb-6.mb-6.content-inner-editer'

            # Wait for the promo details to load
            WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, promo_details_css)))
        
            # Get the important information from the promo page
            promo_details_element = driver.find_element(By.CSS_SELECTOR, promo_details_css)

            # Extract the promo title, period, and description
            promo_title = promo_details_element.find_element(By.CSS_SELECTOR, 'h3').text
            
            promo_period_element = promo_details_element.find_element(By.CSS_SELECTOR, 'p:nth-of-type(2)')
            promo_period_text = promo_period_element.text
            
            # Keep everything after the first digit is encountered
            promo_period = re.search(r'[0-9].*', promo_period_text).group()
            
            promo_description_element = promo_details_element.find_element(By.CSS_SELECTOR, 'ul:nth-of-type(1)')
            promo_description = promo_description_element.text
            
            # Remove the last sentence from the description
            last_sentence_index = promo_description.rfind('.')
            if last_sentence_index != -1:
                promo_description = promo_description[:last_sentence_index]
                
            # Store the data in a dictionary and append to the list
            promo_data.append({
                "title": promo_title,
                "period": promo_period.replace('Период: ', '').strip(),  # Removing the leading text and trimming whitespace
                "description": promo_description
            })

            # Navigate back to the main promo page
            driver.back()
            # Wait for the promo boxes to load again after navigating back
            WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, '#stock-wrap > div > a')))

finally:
    # Close the browser window
    driver.quit()

# Print the extracted data
for promo in promo_data:
    print(promo)
    print("=========================================")
