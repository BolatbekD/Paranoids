import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import io
import os
from google.cloud import vision
from google.oauth2 import service_account
import openai
import firebase_admin
from firebase_admin import credentials, firestore
import json
import re

def delete_collection(coll_ref, batch_size):
    if batch_size == 0:
        return

    docs = coll_ref.list_documents(page_size=batch_size)
    deleted = 0

    for doc in docs:
        print(f"Deleting doc {doc.id} => {doc.get().to_dict()}")
        doc.delete()
        deleted = deleted + 1

    if deleted >= batch_size:
        return delete_collection(coll_ref, batch_size)

def extract_cashback_info(text):
    openai.api_key = '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'

    try:
        text = text + 'retrieve conditions shortly. /nreturn answer stickly in following format in english : name of shop, should be in one or two words : conditions for cashback in around 15 words'
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",

            messages=[{"role": "user", "content": text}],
            max_tokens=100
        )

        content = response.choices[0].message['content']
        # Example (you need to implement the actual parsing):


        return content

    except Exception as e:
        print("Failed to retrieve information:", e)
        return {}

# Path to your service account key file
key_path = r"C:\Users\user\Desktop\Hackaton\neat-bricolage-420211-firebase-adminsdk-tzra2-5d9980111e.json"
cred = credentials.Certificate(key_path)
firebase_admin.initialize_app(cred)
db = firestore.client()
# Setup the client with explicit credentials
credentials = service_account.Credentials.from_service_account_file(key_path)

client = vision.ImageAnnotatorClient(credentials=credentials)

def detect_text_from_url(url):
    """Detects text in the image located in the given URL."""
    image = vision.Image()
    image.source.image_uri = url

    response = client.text_detection(image=image)
    texts = response.text_annotations

    full_text = ''
    if texts:
        print("Texts:")
        full_text = texts[0].description  # Assuming the first element contains all text
        print(full_text)
    else:
        print('No text detected.')

    if response.error.message:
        raise Exception(f'{response.error.message}')

    return full_text

def delete_text_with_pattern(text):
    if re.search(r'0\.0\.', text):
        return True  # Return empty string if the pattern is found

    # Check if the text matches the negative percentage pattern
    if re.search(r'-\d+%', text):
        return True  # Return None if the text contains negative percentages

    return False

def process_cashback_data(promo_data):
    """Processes cashback data from Firestore, analyzes images, and updates Firestore."""

    for promo in promo_data:


        # Initialize an empty dictionary to store promo information
        promo_dict = promo

        pattern = r'^(\d+)%'

        # Use re.search to find the first occurrence of the pattern in the string
        match = re.search(pattern, promo_dict['title'])

        cashback_rate = int(match.group(1))

        date_range = promo_dict['period']


        # Split the string by whitespace
        date_parts = date_range.split()

        # Extract the start and end dates
        start_date = date_parts[0]
        end_date = date_parts[2]




        full_text = f"{promo_dict['title']} retrieve shop name, /n {promo_dict['description']}"
        info = extract_cashback_info(full_text)
        parts = info.split(':')


        # Extract the start and end dates
        cashback_category = parts[0].strip()
        try:
            conditions =parts[1].strip()
        except Exception as e:
            conditions = ''



        # Attempt to parse the info into a dictionary if it's not a string indicating no cashback
        data = {
            "cashback_category": cashback_category,
            "start_date": start_date,
            "end_date": end_date,
            "cashback_rate": cashback_rate,
            "conditions": conditions
                # Add more fields as needed
        }

        db.collection("halyk_promo").document().set(data)







# Launch the Chrome browser
driver = webdriver.Chrome()

# Open the webpage
driver.get("https://halykbank.kz/promo")

try:
    # Wait for the promo boxes to load
    WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, '#stock-wrap > div > a')))

    # Find all promo boxes
    promo_boxes = driver.find_elements(By.CSS_SELECTOR, '#stock-wrap > div > a')

    # Create lists to store the extracted data
    promo_data = []

    # Iterate through each promo box
    for box in promo_boxes:
        # Get the text of the promo description
        promo_text = box.find_element(By.CSS_SELECTOR, 'div > div > div').text

        # Check if the promo contains "%"
        if "%" in promo_text:
            # Click on the promo box to navigate to the promo page
            box.click()

            # Define the CSS selector for the promo details container
            promo_details_css = 'div.border-b.border-gray-100.pb-6.mb-6.content-inner-editer'

            # Wait for the promo details to load
            WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, promo_details_css)))

            # Get the important information from the promo page
            promo_details_element = driver.find_element(By.CSS_SELECTOR, promo_details_css)

            # Extract the promo title, period, and description
            promo_title = promo_details_element.find_element(By.CSS_SELECTOR, 'h3').text

            promo_period_element = promo_details_element.find_element(By.CSS_SELECTOR, 'p:nth-of-type(2)')
            promo_period_text = promo_period_element.text

            # Keep everything after the first digit is encountered
            promo_period = re.search(r'[0-9].*', promo_period_text).group()

            promo_description_element = promo_details_element.find_element(By.CSS_SELECTOR, 'ul:nth-of-type(1)')
            promo_description = promo_description_element.text

            # Remove the last sentence from the description
            last_sentence_index = promo_description.rfind('.')
            if last_sentence_index != -1:
                promo_description = promo_description[:last_sentence_index]

            # Store the data in a dictionary and append to the list
            promo_data.append({
                "title": promo_title,
                "period": promo_period.replace('Период: ', '').strip(),  # Removing the leading text and trimming whitespace
                "description": promo_description
            })

            # Navigate back to the main promo page
            driver.back()
            # Wait for the promo boxes to load again after navigating back
            WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, '#stock-wrap > div > a')))

finally:
    # Close the browser window
    driver.quit()

    coll_ref = db.collection("halyk_promo")
    delete_collection(coll_ref, 50)
    process_cashback_data(promo_data)
