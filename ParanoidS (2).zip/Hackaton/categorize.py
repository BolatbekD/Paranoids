import io
import os
import openai
import firebase_admin
from firebase_admin import credentials, firestore


# Define your list of categories
CATEGORIES = ["Electronics", "Sport", "Kids", "Household", "Selfcare", "Free time", "Automobile"]

# Set up Firebase
def initialize_firebase():
    key_path = r'C:\Users\botik\OneDrive\Рабочий стол\hackaton\neat-bricolage-420211-firebase-adminsdk-tzra2-5d9980111e.json'  # Replace with your Firebase key path
    cred = credentials.Certificate(key_path)
    firebase_admin.initialize_app(cred)
    db = firestore.client()
    return db

# Initialize OpenAI
def initialize_openai():
    openai.api_key = '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'
    if not openai.api_key:
        raise EnvironmentError("OpenAI API key not set in environment variables")

   # Function to extract and format cashback information using ChatGPT
def classify_discount(description):
    try:
        # Format the list into a string that can be included in the prompt
        formatted_categories = ', '.join(f'"{category}"' for category in CATEGORIES)
        prompt = (f"Please choose the most relevant category based on the description. STRICTLY Check the company names/brand names to understand their category. For example, 'laptop' or 'electonics shops' go into 'Electronics', 'soccer ball' goes into 'Sport', 'children's clothes' goes into 'Kids', 'tools' goes into 'Household', 'facial cleanser' goes into 'Selfcare',  and 'car tire' goes into 'Automobile'.Here is a description of a cashback offer: '{description}'. "
                  f"Items directly associated with activities for relaxing, such as 'Books', should be categorized under 'Leisure'. Sports activities should be under Sports. If you leave more discounts uncategorized you can double check again if there is a category that maybe suits. Which of the following categories does it belong to? {formatted_categories}")

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=60
        )
        # Assuming the API returns one of the categories directly
        category = response.choices[0].message['content'].strip().replace('"', '')

        # Validate that the response is one of the predefined categories
        if category in CATEGORIES:
            return category
        else:
            return "Uncategorized"

    except Exception as e:
        print(f"An error occurred during classification: {e}")
        return "Uncategorized"

# Function to fetch discounts from a specific bank's collection, classify them, and organize them into categories
# Function to fetch discounts from a specific bank's collection, classify them, and organize them into categories
def organize_discounts_by_category(bank_collection):
    bank_discounts_ref = db.collection(bank_collection)
    discounts = bank_discounts_ref.stream()

    for discount in discounts:
        discount_data = discount.to_dict()
        cashback_description = discount_data.get('cashback_category', 'Uncategorized')

        # Classify the cashback description
        general_category = classify_discount(cashback_description)

        # Firestore paths must be URL-friendly. Replace spaces and slashes with underscores.
        general_category_safe = general_category.replace(' ', '_').replace('/', '_')

        # Check if the category is one of the predefined categories
        if general_category_safe not in CATEGORIES:
            general_category_safe = "Uncategorized"

        # Store or update the data in Firestore under a collection named after the general category
        category_ref = db.collection('general_categories').document(general_category_safe)
        category_ref.collection(bank_collection).add(discount_data)

if __name__ == "__main__":
    db = initialize_firebase()
    initialize_openai()
    banks = ['kaspi_discounts', 'halyk_promo']  # Add 'jusan_promo' later
    for bank in banks:
        organize_discounts_by_category(bank)
