from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import sys
import io
import io
import os
from google.cloud import vision
from google.oauth2 import service_account
import openai
import firebase_admin
from firebase_admin import credentials, firestore
import json
import re
# Set stdout encoding to UTF-8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf8')

driver = webdriver.Chrome()
driver.get("https://jusan.kz/bonus")

def extract_cashback_info(text):
    openai.api_key = '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'

    try:
        text = text + '\n Answer what is QR cashback, special cashback, and description of special cashback. return answer strickly in following given format int : int : String'
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",

            messages=[{"role": "user", "content": text}],
            max_tokens=100
        )

        content = response.choices[0].message['content']
        # Example (you need to implement the actual parsing):


        return content

    except Exception as e:
        print("Failed to retrieve information:", e)
        return {}

def process_cashback_data(bonus_details_set):

    for bonus_name, bonus_description in bonus_details_set:
        info = extract_cashback_info(bonus_description)
        parts = info.split(':')


        # Extract the start and end dates
        cashback_qr = parts[0].strip()
        cashback_special = parts[1].strip()
        try:
            description =parts[2].strip()
        except Exception as e:
            description = ''
        # Attempt to parse the info into a dictionary if it's not a string indicating no cashback
        if info.strip() != '{"Not a CashBack"}':
            try:

                db.collection('QR').document(f'Jusan {bonus_name}').set({"cashback_rate":cashback_special.replace('+', '').replace('%', '')})
                db.collection('Special').document(f'Jusan {bonus_name}').set({"first_rate":cashback_qr.replace('+', '').replace('%', ''), "first_description": description})
            except json.JSONDecodeError:
                print("Failed to parse the information into a dictionary:", info)
        else:
            print("No valid cashback information found for:", url)

try:
    detail_buttons = WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, '.bonus-category_card_btn__iCQ09'))
    )
    bonus_details_set = set()  # Store bonus details in a set to remove duplicates
    for button in detail_buttons:
        driver.execute_script("arguments[0].scrollIntoView();", button)
        driver.execute_script("arguments[0].click();", button)
        WebDriverWait(driver, 60).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, '.bonus-category_bonus_modal_text__FLrdo'))
        )

        # Extract information after ensuring it's loaded
        bonus_details = driver.find_elements(By.CSS_SELECTOR, '.bonus-category_bonus_modal_text__FLrdo')
        for detail in bonus_details:
            bonus_name = detail.find_element(By.CSS_SELECTOR, '.bonus-category_bonus_name__sOZ_d').text
            bonus_description = detail.text.replace(bonus_name, '').strip()
            bonus_details_set.add((bonus_name, bonus_description))

    # Print unique bonus details
    for bonus_name, bonus_description in bonus_details_set:
        print("Bonus Name:", bonus_name)
        print("Description:", bonus_description)
        print()

except Exception as e:
    print(f"An error occurred: {str(e)}")
    driver.save_screenshot('debug_screenshot.png')  # Save a screenshot for debugging

finally:
    driver.quit()
    key_path = r"C:\Users\user\Desktop\Hackaton\neat-bricolage-420211-firebase-adminsdk-tzra2-5d9980111e.json"
    cred = credentials.Certificate(key_path)
    firebase_admin.initialize_app(cred)
    db = firestore.client()
    process_cashback_data(bonus_details_set)
