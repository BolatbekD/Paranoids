import re
from selenium import webdriver
from selenium.webdriver.common.by import By
import io
import os
from google.cloud import vision
from google.oauth2 import service_account
import openai
import firebase_admin
from firebase_admin import credentials, firestore
import json
import re

def delete_collection(coll_ref, batch_size):
    if batch_size == 0:
        return

    docs = coll_ref.list_documents(page_size=batch_size)
    deleted = 0

    for doc in docs:
        print(f"Deleting doc {doc.id} => {doc.get().to_dict()}")
        doc.delete()
        deleted = deleted + 1

    if deleted >= batch_size:
        return delete_collection(coll_ref, batch_size)


def extract_cashback_info(text):
    openai.api_key = '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'

    try:
        text = text + ' /nReturn the best word to categorize cashback in russian'
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",

            messages=[{"role": "user", "content": text}],
            max_tokens=100
        )

        content = response.choices[0].message['content']
        # Example (you need to implement the actual parsing):


        return content

    except Exception as e:
        print("Failed to retrieve information:", e)
        return {}

# Set up WebDriver
driver = webdriver.Chrome()

# Open the web page
driver.get("https://eubank.kz/bonus-program/")

try:
    # Find the bonuses for the "Авто" category
    auto_bonuses = driver.find_element(By.CSS_SELECTOR, "#tab div.tab__contents div.tab__section.is-active div.tab__inner ul:nth-child(4) li:nth-child(2)").text

    # Find the bonuses for the "Развлечения" category
    entertainment_bonuses = driver.find_element(By.CSS_SELECTOR, "#tab div.tab__contents div.tab__section.is-active div.tab__inner ul:nth-child(4) li:nth-child(3)").text

    # Parse bonuses into percentage and title fields for Авто
    auto_percentage, auto_title = auto_bonuses.split(' ', 1)

    # Parse bonuses into percentage and title fields for Развлечения
    entertainment_percentage, entertainment_title = entertainment_bonuses.split(' ', 1)

    # Common bonuses
    common_bonus_1 = driver.find_element(By.CSS_SELECTOR, "#tab > div.tab__contents > div.tab__section.is-active > div.tab__inner > ul:nth-child(3) > li:nth-child(2)")
    common_bonus_1_text = common_bonus_1.text
    common_bonus_1_per, common_bonus_1_title = common_bonus_1_text.split(' ', 1)

    common_bonus_2 = driver.find_element(By.CSS_SELECTOR, "#tab > div.tab__contents > div.tab__section.is-active > div.tab__inner > ul:nth-child(4) > li:nth-child(1)")
    common_bonus_2_text = common_bonus_2.text
    common_bonus_2_per, common_bonus_2_title = common_bonus_2_text.split(' ', 1)

    # Print the bonuses
    print("Percentage:", common_bonus_1_per)
    print("Title:", common_bonus_1_title)

    print("Percentage:", common_bonus_2_per)
    print("Title:", common_bonus_2_title)

    print("Percentage:", auto_percentage)
    print("Title:", auto_title)

    print("Percentage:", entertainment_percentage)
    print("Title:", entertainment_title)

finally:
    # Quit the WebDriver
    driver.quit()
    key_path = r"C:\Users\user\Desktop\Hackaton\neat-bricolage-420211-firebase-adminsdk-tzra2-5d9980111e.json"
    cred = credentials.Certificate(key_path)
    firebase_admin.initialize_app(cred)
    db = firestore.client()
    db.collection("Special").document("Eurasian_Autocard").set({
        "first_rate": common_bonus_1_per.replace('+', '').replace('%', ''),
        "first_description": common_bonus_1_title
    })
    db.collection("Card").document("Eurasian_Autocard").set({"cashback_rate": common_bonus_2_per.replace('+', '').replace('%', '')})

    coll_ref = db.collection("eurasian_autotcard_discounts")
    delete_collection(coll_ref, 50)
    db.collection("eurasian_autotcard_discounts").document().set({"cashback_category": extract_cashback_info(auto_title), "cashback_rate": auto_percentage.replace('+', '').replace('%', '')})
    db.collection("eurasian_autocard_discounts").document().set({"cashback_category": extract_cashback_info(entertainment_title), "cashback_rate": entertainment_percentage.replace('+', '').replace('%', '')})
