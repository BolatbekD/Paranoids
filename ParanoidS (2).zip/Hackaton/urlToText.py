import io
import os
from google.cloud import vision
from google.oauth2 import service_account
import openai
import firebase_admin
from firebase_admin import credentials, firestore
import json
import re

def delete_collection(coll_ref, batch_size):
    if batch_size == 0:
        return

    docs = coll_ref.list_documents(page_size=batch_size)
    deleted = 0

    for doc in docs:
        print(f"Deleting doc {doc.id} => {doc.get().to_dict()}")
        doc.delete()
        deleted = deleted + 1

    if deleted >= batch_size:
        return delete_collection(coll_ref, batch_size)

def extract_cashback_info(text):
    openai.api_key = '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'

    try:
        text = text + 'return answer stickly in following format {"cashback_category": "(String with only one to three words meaning Category in russian, only first letter is capital)","start_date": "(start_date in format dd.mm.yyyy)","end_date": "(end_date in format dd.mm.yyyy)", "cashback_rate": "(float cashback_rate)" \n  }'
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",

            messages=[{"role": "user", "content": text}],
            max_tokens=100
        )

        content = response.choices[0].message['content']
        # Example (you need to implement the actual parsing):


        return content

    except Exception as e:
        print("Failed to retrieve information:", e)
        return {}

# Path to your service account key file
key_path = r"C:\Users\user\Desktop\Hackaton\neat-bricolage-420211-firebase-adminsdk-tzra2-5d9980111e.json"
cred = credentials.Certificate(key_path)
firebase_admin.initialize_app(cred)
db = firestore.client()
# Setup the client with explicit credentials
credentials = service_account.Credentials.from_service_account_file(key_path)

client = vision.ImageAnnotatorClient(credentials=credentials)

def detect_text_from_url(url):
    """Detects text in the image located in the given URL."""
    image = vision.Image()
    image.source.image_uri = url

    response = client.text_detection(image=image)
    texts = response.text_annotations

    full_text = ''
    if texts:
        print("Texts:")
        full_text = texts[0].description  # Assuming the first element contains all text
        print(full_text)
    else:
        print('No text detected.')

    if response.error.message:
        raise Exception(f'{response.error.message}')

    return full_text

def delete_text_with_pattern(text):
    if re.search(r'0\.0\.', text):
        return True  # Return empty string if the pattern is found

    # Check if the text matches the negative percentage pattern
    if re.search(r'-\d+%', text):
        return True  # Return None if the text contains negative percentages

    return False

def process_cashback_data():
    """Processes cashback data from Firestore, analyzes images, and updates Firestore."""
    kaspi_discounts_ref = db.collection('kaspi_discounts_urls')
    discounts = kaspi_discounts_ref.stream()

    for discount in discounts:
        period = discount.to_dict().get('Period')
        url = discount.to_dict().get('URL')
        text_from_image = detect_text_from_url(url)

        if (delete_text_with_pattern(text_from_image)):
            continue
        full_text = f"{period} {text_from_image}"
        info = extract_cashback_info(full_text)

        # Attempt to parse the info into a dictionary if it's not a string indicating no cashback
        if info.strip() != '{"Not a CashBack"}':
            try:
                # Convert the string response to a dictionary
                info_dict = json.loads(info.replace("'", "\""))  # Ensure JSON format compatibility
                # If cashback info exists and is valid, save it to Firestore
                db.collection('kaspi_discounts').add(info_dict)
            except json.JSONDecodeError:
                print("Failed to parse the information into a dictionary:", info)
        else:
            print("No valid cashback information found for:", url)

coll_ref = db.collection("kaspi_discounts")
delete_collection(coll_ref, 50)
# Example call to process data
process_cashback_data()
