import re
from selenium import webdriver
from selenium.webdriver.common.by import By
import io
import os
from google.cloud import vision
from google.oauth2 import service_account
import openai
import firebase_admin
from firebase_admin import credentials, firestore
import json
import re




# Set up WebDriver
driver = webdriver.Chrome()

# Open the ForteBank Travel card page
driver.get("https://bank.forte.kz/cards/travelcard?_gl=1*yc2ng7*_ga*MTEzNDk4OTYwMy4xNzEyOTkxMjM5*_ga_P6DFNQT8GT*MTcxMzA0NjczNS4zLjEuMTcxMzA0ODI0Ni4zNS4wLjA.#!")

try:
    # Find and print the common bonuses for the Travel card
    # Common bonuses
    common_bonus_1 = driver.find_element(By.CSS_SELECTOR, "#__next > main > div:nth-child(14) > div > div.sc-ipNeGl.cthzou > div.sc-jhDJkI.bONmDS > p:nth-child(2)")
    common_bonus_1_text = common_bonus_1.text

    # Extract percentage and title
    match = re.search(r'(\d+%)', common_bonus_1_text)  # Find percentage using regex
    common_bonus_1_per = match.group(1) if match else ""  # Extract percentage if found
    common_bonus_1_title = common_bonus_1_text.strip()  # Remove percentage from title

    common_bonus_2 = driver.find_element(By.CSS_SELECTOR, "#__next > main > div:nth-child(14) > div > div.sc-ipNeGl.cthzou > div.sc-jhDJkI.bONmDS > p:nth-child(3)")
    common_bonus_2_text = common_bonus_2.text

    # Extract percentage and title
    match = re.search(r'(\d+%)', common_bonus_2_text)  # Find percentage using regex
    common_bonus_2_per = match.group(1) if match else ""  # Extract percentage if found
    common_bonus_2_title = common_bonus_2_text.strip()  # Remove percentage from title

    # Print the bonuses
    print("Percentage: <", common_bonus_1_per)
    print("Title:", common_bonus_1_title)

    print("Percentage: <", common_bonus_2_per)
    print("Title:", common_bonus_2_title)


    # Find and print the travel bonus
    travel_bonus_element = driver.find_element(By.CSS_SELECTOR, "#__next > main > div:nth-child(14) > div > div.sc-ipNeGl.cthzou > div.sc-jhDJkI.bONmDS > p:nth-child(1)")
    travel_bonus_text = travel_bonus_element.text

    # Crop the travel bonus string to the relevant part
    match = re.search(r'категория «Путешествия» \d+%', travel_bonus_text)
    cropped_bonus = match.group() if match else ""

    # Extract percentage and construct the title
    match = re.search(r'(\d+%)', cropped_bonus)  # Find percentage using regex
    percentage = match.group(1) if match else ""  # Extract percentage if found
    title = cropped_bonus.replace(percentage, "").strip()  # Remove percentage from title

    # Print the bonuses
    print("Percentage:", percentage)
    print("Title:", title)

finally:
    # Close the WebDriver
    driver.quit()

    key_path = r"C:\Users\user\Desktop\Hackaton\neat-bricolage-420211-firebase-adminsdk-tzra2-5d9980111e.json"
    cred = credentials.Certificate(key_path)
    firebase_admin.initialize_app(cred)
    db = firestore.client()
    db.collection("Special").document("Forte_Travel").set({
        "first_rate": common_bonus_1_per.replace('+', '').replace('%', ''),
        "first_description": common_bonus_1_title,
        "second_rate": common_bonus_2_per.replace('+', '').replace('%', ''),
        "second_description": common_bonus_2_title,
        "third_rate": percentage.replace('+', '').replace('%', ''),
        "third_description": title
    })
