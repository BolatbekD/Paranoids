import subprocess

# List your scripts to run in sequence
scripts = [
    'kaspi_shop_scrape.py',
    'halykPromo.py',
    'halyk.py',
    'urlToText.py',
    'jusan2.py',

    'forte_black.py',
    'forte_blue.py',
    'forte_travel.py',

    'eurasian_avtocarta.py',
    'eurasian_goldpremium.py',
    'eurasian_smartcard.py',
    'categorize.py'
    # Add as many scripts as you need
]

# Run each script sequentially
for script in scripts:
    print(f"Running {script}...")
    subprocess.run(['python', script], check=True)
    print(f"Finished running {script}.")

print("Finished running all scripts.")
